const { response } = require("express");

exports.sayHi = (Request,response) =>{
response.json({message: " hello"});
};